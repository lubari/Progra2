package tdas;

public class QueueStack implements IQueue{
    private final StaticStack[] array;
    private int currentStack;
    private int countStack;

    public QueueStack(int n) {
        this.array = new StaticStack[n];
        currentStack = 0;
    }

    @Override
    public void add(int a) {
        if(this.currentStack == 0){
            this.array[currentStack] = new StaticStack();
        }
        if(this.array[currentStack] == null || this.countStack == this.array.length){
            this.countStack = 0;
            this.currentStack++;
            this.array[currentStack] = new StaticStack();
        }
        this.array[currentStack].add(a);
        this.countStack++;
    }

    @Override
    public void remove() {

    }

    @Override
    public boolean isEmpty() {
        return false;
    }

    @Override
    public int getFirst() {
        return 0;
    }
}
